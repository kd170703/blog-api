class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///blog.db'  # Путь к базе данных SQLite
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # Отключаем уведомления о модификациях

